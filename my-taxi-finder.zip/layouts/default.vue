<template>
    <div>
        <nav class="navbar navbar-expand navbar-dark bg-dark d-block">
            <a class="navbar-brand" href="#">My Taxi Finder</a>
        </nav>
    <nuxt />
    </div>
</template>
